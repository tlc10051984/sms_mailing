<form action="<?php $_SERVER['REQUEST_URI']?>" method="POST">    
   
   <input type='text' value='REX' size="12" name='sms_name'></br></br>
   <input type='submit' value='Заказать' class='button1' name='order'>

</form>