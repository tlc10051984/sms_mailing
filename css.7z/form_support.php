<form action="<?php $_SERVER['REQUEST_URI']?>" method="POST"> 
   <b>Дополнительный комментарий оператора</b><br/>
   <textarea name="comment" rows="5" cols="45"></textarea><br/><br/>
   <input type='submit' value='Подтвердить' class='button1' name='yes'>
   <input type='submit' value='Отказать' class='button1' name='no'>

</form>